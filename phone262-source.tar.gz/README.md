# SmartPhone Economy — Minecraft Java 26.2 Fabric

Java Edition port target based on the user-supplied `smartphone_s2.mcaddon` as the visual/name reference.

## App names kept from the reference
Bank, Shop, Calculator, Music, Theme, Camera, Games, Website, Settings, Messages, Weather, Profile, GameMode, Location.

## Target
- Minecraft Java 26.2
- Fabric Loader 0.19.3
- Fabric API 0.158.0+26.2
- Java 25+
- Mojang mappings (required for Minecraft 26.2+)

The phone opens by using the Smartphone item. The home screen uses the supplied addon app icons as visual references. No PIN is included.

## Build
Run `./gradlew build` (or `gradle build` if Gradle is installed globally). The normal JAR is in `build/libs`.

Important: Minecraft 26.2 development requires JDK 25 according to the current Fabric documentation.
