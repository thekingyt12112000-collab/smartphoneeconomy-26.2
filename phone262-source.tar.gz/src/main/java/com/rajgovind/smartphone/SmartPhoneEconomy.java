package com.rajgovind.smartphone;

import com.rajgovind.smartphone.item.PhoneItem;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.Registry;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;

public class SmartPhoneEconomy implements ModInitializer {
    public static final String MOD_ID = "smartphoneeconomy";
    public static final Item SMARTPHONE = new PhoneItem(new Item.Properties().stacksTo(1));

    @Override
    public void onInitialize() {
        Registry.register(BuiltInRegistries.ITEM, ResourceLocation.fromNamespaceAndPath(MOD_ID, "smartphone"), SMARTPHONE);
        ItemGroupEvents.modifyEntriesEvent(CreativeModeTabs.TOOLS_AND_UTILITIES).register(entries -> entries.accept(SMARTPHONE));
    }
}
