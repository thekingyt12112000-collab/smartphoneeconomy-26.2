package com.rajgovind.smartphone.client;

import com.rajgovind.smartphone.SmartPhoneEconomy;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.event.player.ItemEvents;
import net.minecraft.client.Minecraft;
import net.minecraft.world.InteractionResult;

public class SmartPhoneEconomyClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        ItemEvents.USE.register((stack, level, player, hand) -> {
            if (stack.is(SmartPhoneEconomy.SMARTPHONE) && level.isClientSide()) {
                Minecraft.getInstance().setScreen(new PhoneScreen());
                return InteractionResult.SUCCESS;
            }
            return InteractionResult.PASS;
        });
    }
}
