package com.rajgovind.smartphone.client;

import com.rajgovind.smartphone.SmartPhoneEconomy;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemStack;

import java.util.List;

/**
 * Smartphone-style home screen. App names intentionally follow the supplied addon:
 * Bank, Shop, Calculator, Music, Theme, Camera, Games, Website, Settings,
 * Messages, Weather, Profile, GameMode and Location.
 */
public class PhoneScreen extends Screen {
    private static final int PHONE_W = 330;
    private static final int PHONE_H = 520;
    private static final ResourceLocation PHONE_BG = ResourceLocation.fromNamespaceAndPath(SmartPhoneEconomy.MOD_ID, "textures/phone/phone_background.png");

    private record App(String name, String icon, int x, int y) {}

    private static final List<App> APPS = List.of(
        new App("Bank", "bank_app", 0, 0),
        new App("Shop", "shop_app", 1, 0),
        new App("Calculator", "caculator_app", 2, 0),
        new App("Music", "spotify", 3, 0),
        new App("Theme", "theme_app", 0, 1),
        new App("Camera", "camera_app", 1, 1),
        new App("Games", "game_12", 2, 1),
        new App("Website", "broswer_app", 3, 1),
        new App("Settings", "setting_app", 0, 2),
        new App("Messages", "msg_app", 1, 2),
        new App("Weather", "wether_app", 2, 2),
        new App("Profile", "profile_app", 3, 2),
        new App("GameMode", "gamemode_app", 0, 3),
        new App("Location", "postion_app", 1, 3)
    );

    private String page = "Home";
    private EditBox playerBox;
    private EditBox amountBox;

    public PhoneScreen() {
        super(Component.literal("SmartPhone"));
    }

    @Override
    protected void init() {
        rebuild();
    }

    private void rebuild() {
        clearWidgets();
        playerBox = null;
        amountBox = null;

        int left = (width - PHONE_W) / 2;
        int top = (height - PHONE_H) / 2;

        if (page.equals("Home")) {
            for (App app : APPS) {
                int x = left + 28 + app.x() * 69;
                int y = top + 92 + app.y() * 82;
                addRenderableWidget(Button.builder(Component.literal(app.name()), b -> openApp(app.name()))
                    .bounds(x, y + 50, 62, 20).build());
            }
            addRenderableWidget(Button.builder(Component.literal("Close"), b -> onClose())
                .bounds(left + 103, top + 456, 124, 28).build());
            return;
        }

        addRenderableWidget(Button.builder(Component.literal("‹ Back"), b -> { page = "Home"; rebuild(); })
            .bounds(left + 20, top + 58, 80, 24).build());

        if (page.equals("Send Money")) {
            playerBox = new EditBox(font, left + 35, top + 125, 260, 24, Component.literal("Player"));
            playerBox.setHint(Component.literal("Player name"));
            amountBox = new EditBox(font, left + 35, top + 165, 260, 24, Component.literal("Amount"));
            amountBox.setHint(Component.literal("Amount"));
            addRenderableWidget(playerBox);
            addRenderableWidget(amountBox);
            addRenderableWidget(Button.builder(Component.literal("Send Money"), b -> runCommand("phone pay " + playerBox.getValue() + " " + amountBox.getValue()))
                .bounds(left + 80, top + 210, 170, 28).build());
        } else if (page.equals("Bank")) {
            addRenderableWidget(Button.builder(Component.literal("Balance"), b -> runCommand("phone balance"))
                .bounds(left + 80, top + 115, 170, 28).build());
            addRenderableWidget(Button.builder(Component.literal("Deposit Diamond"), b -> runCommand("phone deposit diamond 1"))
                .bounds(left + 80, top + 150, 170, 28).build());
            addRenderableWidget(Button.builder(Component.literal("Withdraw Diamond"), b -> runCommand("phone withdraw diamond 1"))
                .bounds(left + 80, top + 185, 170, 28).build());
        } else if (page.equals("Shop")) {
            addRenderableWidget(Button.builder(Component.literal("Open Shop"), b -> runCommand("phone shop"))
                .bounds(left + 80, top + 115, 170, 28).build());
            addRenderableWidget(Button.builder(Component.literal("Buy Diamond"), b -> runCommand("phone buy diamond 1"))
                .bounds(left + 80, top + 150, 170, 28).build());
        } else {
            addRenderableWidget(Button.builder(Component.literal("Open " + page), b -> {})
                .bounds(left + 80, top + 125, 170, 28).build());
        }
    }

    private void openApp(String name) {
        page = name.equals("Bank") ? "Bank" : name.equals("Shop") ? "Shop" : name.equals("Messages") ? "Send Money" : name;
        rebuild();
    }

    private void runCommand(String command) {
        if (Minecraft.getInstance().getConnection() != null) {
            Minecraft.getInstance().getConnection().sendCommand(command);
        }
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        int left = (width - PHONE_W) / 2;
        int top = (height - PHONE_H) / 2;

        g.fill(0, 0, width, height, 0x99000000);
        g.fill(left, top, left + PHONE_W, top + PHONE_H, 0xFF090B10);
        g.fill(left + 7, top + 7, left + PHONE_W - 7, top + PHONE_H - 7, 0xFF182133);
        g.fill(left + 18, top + 18, left + PHONE_W - 18, top + 48, 0xFF0D1420);
        g.drawString(font, Component.literal("SmartPhone"), left + 30, top + 29, 0xFFFFFFFF, true);
        g.drawString(font, Component.literal("12:34"), left + PHONE_W - 62, top + 29, 0xFFBFD7FF, false);
        g.drawCenteredString(font, Component.literal(page), width / 2, top + 65, 0xFF8ED1FF);

        if (page.equals("Home")) {
            for (App app : APPS) {
                int x = left + 28 + app.x() * 69;
                int y = top + 92 + app.y() * 82;
                ResourceLocation icon = ResourceLocation.fromNamespaceAndPath(SmartPhoneEconomy.MOD_ID, "textures/phone/icons/" + app.icon() + ".png");
                g.blit(icon, x + 17, y, 0, 0, 28, 28, 28, 28);
            }
            g.drawCenteredString(font, Component.literal("Your world. Your phone."), width / 2, top + 435, 0xFFB9C7D8);
        }
        super.render(g, mouseX, mouseY, partialTick);
    }

    @Override
    public boolean isPauseScreen() { return false; }
}
